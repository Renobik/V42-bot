
# Deploy V4.2 to Render (Free 24/7)
1. Push these 3 files to GitHub:
   - top100_choch_v4_2_FINAL_FULL.py
   - requirements.txt
   - Dockerfile
   - render.yaml (optional)

2. Go to https://dashboard.render.com -> New + -> Blueprint -> Connect GitHub repo
   Render reads render.yaml and creates worker.

3. Or: New + -> Background Worker -> Connect repo
   Build: docker
   Start: python top100_choch_v4_2_FINAL_FULL.py

4. Add Env Vars in Render Dashboard:
   TELEGRAM_TOKEN=your_bot_token
   TELEGRAM_CHAT_ID=your_chat_id
   CMC_API_KEY=optional
   BINANCE_API_KEY=leave empty for DRY_RUN signals only
   BINANCE_API_SECRET=leave empty

5. Deploy -> Logs will show: === V4.2 Top100 4H->1H 5% Risk 5x DRY_RUN=True ===
   Telegram will start getting /status /scan replies within 30s.

To go LIVE (real orders): set DRY_RUN=False line 19 in py file, add Binance keys, redeploy.
