# V4.2 Render Deploy

1. Push this folder to GitHub
2. Go to dashboard.render.com -> New + -> Blueprint -> Connect repo (it reads render.yaml)
3. Add env vars: TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, optional CMC_API_KEY, BINANCE_API_KEY/SECRET (leave empty for DRY_RUN signals only)
4. Deploy -> Logs will show "Scan 1 Top100..." and Telegram will get signals

For local test: ./start.sh
