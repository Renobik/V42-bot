#!/bin/bash
pip install -r requirements.txt
python top100_choch_v4_2_FINAL_FULL.py
